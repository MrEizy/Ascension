package net.zic.ascension;

import net.minecraft.client.renderer.block.FluidModel;
import net.minecraft.client.resources.model.sprite.Material;
import net.minecraft.resources.Identifier;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.bus.api.EventPriority;
import net.neoforged.bus.api.IEventBus;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.ModContainer;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.fml.common.Mod;
import net.neoforged.fml.event.lifecycle.FMLClientSetupEvent;
import net.neoforged.neoforge.client.extensions.common.RegisterClientExtensionsEvent;
import net.neoforged.neoforge.common.NeoForge;
import net.neoforged.neoforge.client.event.*;
import net.neoforged.neoforge.client.gui.ConfigurationScreen;
import net.neoforged.neoforge.client.gui.IConfigScreenFactory;
import net.neoforged.neoforge.client.network.ClientPacketDistributor;
import net.zic.ascension.client.keybind.*;
import net.zic.ascension.client.particle.ParticleFieldController;
import net.zic.ascension.client.particle.ParticleFieldParticle;
import net.zic.ascension.client.gui.AscensionHudOverlay;
import net.zic.ascension.client.gui.SkillWheelOverlay;
import net.zic.ascension.client.renderer.TabletOutlineRenderer;
import net.zic.ascension.client.visual.runtime.BarrierShellVisualController;
import net.zic.ascension.client.visual.runtime.ClientRuntimeVisuals;
import net.zic.ascension.client.visual.runtime.GuardianDharmaVisualController;
import net.zic.ascension.client.visual.runtime.WeaponSwingVisualController;
import net.zic.ascension.client.tooltip.AscensionClientTooltipProviders;
import net.zic.ascension.common.AscensionCreativeSections;
import net.zic.ascension.common.fluids.AscFluidTypes;
import net.zic.ascension.common.fluids.AscFluids;
import net.zic.ascension.common.gui.menus.AscMenuTypes;
import net.zic.ascension.common.gui.menus.jade_bottle.JadeBottleScreen;
import net.zic.ascension.common.particle.AscensionParticles;
import net.zic.ascension.network.WeaponSwingRequestPacket;


@Mod(value = AscensionCraft.MOD_ID,dist = Dist.CLIENT)
public class AscensionCraftClient {

    private static final TabletOutlineRenderer TABLET_OUTLINE = new TabletOutlineRenderer();



    public AscensionCraftClient(IEventBus modEventBus, ModContainer modContainer)
    {

        ClientSkillCastKeybind.register();
        modContainer.registerExtensionPoint(IConfigScreenFactory.class, ConfigurationScreen::new);
        modEventBus.addListener(AscensionCraftClient::registerKeyBindings);
        modEventBus.addListener(ClientEvents::onClientSetup);
        modEventBus.addListener(AscensionHudOverlay::registerGuiLayers);
        NeoForge.EVENT_BUS.addListener(AscensionHudOverlay::hideVanillaHealth);

    }

    private static void registerKeyBindings(RegisterKeyMappingsEvent event) {
        event.register(ModKeybinds.CYCLE_MODE);
        event.register(ModKeybinds.OPEN_INTROSPECTION);
        event.register(ModKeybinds.OPEN_SKILL_WHEEL);
    }

    @EventBusSubscriber(modid = AscensionCraft.MOD_ID,value = Dist.CLIENT)
    static class ClientEvents{

        @SubscribeEvent
        public static void registerScreens(RegisterMenuScreensEvent event) {
            event.register(AscMenuTypes.JADE_BOTTLE.get(), JadeBottleScreen::new);
        }

        @SubscribeEvent
        public static void registerParticleFactories(RegisterParticleProvidersEvent event) {
            event.registerSpriteSet(
                    AscensionParticles.PARTICLE_FIELD_SPARK.get(),
                    sprites -> new ParticleFieldParticle.Provider(AscensionCraft.prefix("particle_field_spark"), sprites)
            );
            event.registerSpriteSet(
                    AscensionParticles.PARTICLE_FIELD_WISP.get(),
                    sprites -> new ParticleFieldParticle.Provider(AscensionCraft.prefix("particle_field_wisp"), sprites)
            );
            event.registerSpriteSet(
                    AscensionParticles.PARTICLE_FIELD_BLOB.get(),
                    sprites -> new ParticleFieldParticle.Provider(AscensionCraft.prefix("particle_field_blob"), sprites)
            );
            event.registerSpriteSet(
                    AscensionParticles.PARTICLE_FIELD_MOTE.get(),
                    sprites -> new ParticleFieldParticle.Provider(AscensionCraft.prefix("particle_field_mote"), sprites)
            );
            event.registerSpriteSet(
                    AscensionParticles.PARTICLE_FIELD_PETAL.get(),
                    sprites -> new ParticleFieldParticle.Provider(AscensionCraft.prefix("particle_field_petal"), sprites)
            );
            event.registerSpriteSet(
                    AscensionParticles.PARTICLE_FIELD_RUNE.get(),
                    sprites -> new ParticleFieldParticle.Provider(AscensionCraft.prefix("particle_field_rune"), sprites)
            );
            event.registerSpriteSet(
                    AscensionParticles.PARTICLE_FIELD_THREAD.get(),
                    sprites -> new ParticleFieldParticle.Provider(AscensionCraft.prefix("particle_field_thread"), sprites)
            );
            event.registerSpriteSet(
                    AscensionParticles.PARTCILE_FIELD_PETAL_LOTUS.get(),
                    sprites -> new ParticleFieldParticle.Provider(AscensionCraft.prefix("particle_field_petal_lotus"), sprites)
            );
        }


        @SubscribeEvent
        public static void registerOnClientExtensions(RegisterClientExtensionsEvent event) {
            event.registerFluidType(AscFluidTypes.LIQUIFIED_SPIRITUAL_QI_EXTENSION, AscFluidTypes.LIQUIFIED_SPIRITUAL_QI_TYPE.get());
        }


        @SubscribeEvent
        public static void registerFluidModelsEvent(RegisterFluidModelsEvent event) {
            FluidModel.Unbaked liquifiedSpiritualQiModel = new FluidModel.Unbaked(
                    new Material(Identifier.withDefaultNamespace("block/water_still")),
                    new Material(Identifier.withDefaultNamespace("block/water_flow")),
                    new Material(Identifier.withDefaultNamespace("block/water_overlay")),
                    state -> 0xA129A6FF);

            event.register(liquifiedSpiritualQiModel, AscFluids.LIQUIFIED_SPIRITUAL_QI_SOURCE.get());
            event.register(liquifiedSpiritualQiModel, AscFluids.LIQUIFIED_SPIRITUAL_QI_FLOWING.get());
        }

        @SubscribeEvent
        public static void onRegisterRenderers(EntityRenderersEvent.RegisterRenderers event) {



        }


        @SubscribeEvent
        public static void onRegisterTooltipComponents(RegisterClientTooltipComponentFactoriesEvent event) {

        }


        @SubscribeEvent
        public static void onClientSetup(FMLClientSetupEvent event) {
            event.enqueueWork(() -> {
                AscensionClientTooltipProviders.registerAll();
                BarrierShellVisualController.registerDefaults();
                GuardianDharmaVisualController.registerDefault();
                WeaponSwingVisualController.registerDefault();
                AscensionCreativeSections.register();
            });
        }

    }

    @EventBusSubscriber(modid = AscensionCraft.MOD_ID, value = Dist.CLIENT)
    static class ScrollEvents {
        @SubscribeEvent
        public static void onMouseScroll(InputEvent.MouseScrollingEvent event) {
            TabletScrollHandler.onMouseScroll(event);
        }
    }

    // ── GAME bus events (in-game ticks, rendering) ────────────────────────────
    @EventBusSubscriber(modid = AscensionCraft.MOD_ID, value = Dist.CLIENT)
    static class ClientGameEvents {

        @SubscribeEvent(priority = EventPriority.LOWEST)
        public static void onInteractionKeyMapping(InputEvent.InteractionKeyMappingTriggered event) {
            if (!event.isCanceled()
                    && event.isAttack()
                    && net.minecraft.client.Minecraft.getInstance().player != null) {
                ClientPacketDistributor.sendToServer(new WeaponSwingRequestPacket());
            }
        }

        @SubscribeEvent
        public static void onRenderLevelStage(net.neoforged.neoforge.client.event.RenderLevelStageEvent.AfterTranslucentFeatures event) {
            TABLET_OUTLINE.onRenderLevelStage(event);
            ClientRuntimeVisuals.render(event);
        }

        @SubscribeEvent
        public static void onClientTick(net.neoforged.neoforge.client.event.ClientTickEvent.Post event) {
            TabletKeybindHandler.onClientTick(event);
            IntrospectionKeybindHandler.onClientTick(event);
            SkillWheelOverlay.onClientTick();
            ParticleFieldController.tick();
            ClientRuntimeVisuals.tick();
        }
    }



}
