package net.zic.ascension.common.gui.elements.hud;

import net.lucent.easygui.gui.RenderableElement;
import net.lucent.easygui.gui.UIFrame;
import net.lucent.easygui.gui.elements.built_in.EasyLabel;
import net.lucent.easygui.gui.layout.positioning.rules.PositioningRules;
import net.lucent.easygui.gui.textures.ITextureData;
import net.lucent.easygui.gui.textures.TextureData;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.Identifier;
import net.zic.ascension.AscensionCraft;
import net.zic.ascension.Config;
import net.zic.ascension.common.gui.data.ClientAscensionData;

import java.text.DecimalFormat;

public class StaminaBar extends RenderableElement {
    private static final Identifier TEXTURE = Identifier.fromNamespaceAndPath(
            AscensionCraft.MOD_ID,
            "textures/gui/main/overlays/stamina_bar.png"
    );

    private static final ITextureData BAR_TEXTURE = new TextureData(TEXTURE, 85, 9);
    private static final DecimalFormat FORMAT = new DecimalFormat("#.0");

    public StaminaBar(UIFrame frame) {
        super(frame);
        setWidth(BAR_TEXTURE.getWidth());
        setHeight(BAR_TEXTURE.getHeight());
    }

    private EasyLabel getOrCreateLabel() {
        if (getChildren().isEmpty()) {
            EasyLabel label = new EasyLabel(getUiFrame());
            addChild(label);
            label.setWidth(60);
            label.setHeight(getHeight());
            label.getPositioning().setXPositioningRule(PositioningRules.CENTER);
            label.getPositioning().setX(-label.getWidth() / 2);
            label.setTextPositioningX(EasyLabel.TextPositionRule.CENTER);
            label.setTextPositioningY(EasyLabel.TextPositionRule.CENTER);
            label.setTextColor(-1);
            label.setScaleToFit(true);
        }

        return (EasyLabel) getChildren().getFirst();
    }

    @Override
    public void render(GuiGraphicsExtractor graphics, int mouseX, int mouseY, float partialTick) {
        double currentStamina = ClientAscensionData.getStamina();
        double maximumStamina = ClientAscensionData.getMaximumStamina();
        double displayedStamina = maximumStamina <= 0.0D
                ? Math.max(0.0D, currentStamina)
                : Math.clamp(currentStamina, 0.0D, maximumStamina);
        double progress = maximumStamina <= 0.0D
                ? 0.0D
                : displayedStamina / maximumStamina;

        updateLabel(displayedStamina, maximumStamina);

        int width = (int) Math.round(getWidth() * progress);
        if (width > 0) {
            BAR_TEXTURE.render(graphics, width, getHeight());
        }

        super.render(graphics, mouseX, mouseY, partialTick);
    }

    private void updateLabel(double currentStamina, double maximumStamina) {
        if (!Config.CLIENT.SHOW_EXACT_HUD_VALUES.get()) {
            clearLabel();
            return;
        }

        getOrCreateLabel().setText(Component.literal(
                FORMAT.format(currentStamina) + "/" + FORMAT.format(maximumStamina)
        ));
    }

    private void clearLabel() {
        if (!getChildren().isEmpty()) {
            ((EasyLabel) getChildren().getFirst()).setText(Component.empty());
        }
    }
}
