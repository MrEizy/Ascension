package net.zic.ascension.impl.datapack.technique;

import net.neoforged.bus.api.IEventBus;
import net.neoforged.neoforge.registries.DeferredHolder;
import net.neoforged.neoforge.registries.DeferredRegister;
import net.zic.ascension.AscensionCraft;
import net.zic.ascension.api.ascension.datapack.TypeRegistries;
import net.zic.ascension.api.ascension.datapack.technique.TechniqueType;

public class AscensionTechniqueTypes {
    public static final DeferredRegister<TechniqueType> TECHNIQUE_TYPES =
            DeferredRegister.create(TypeRegistries.TECHNIQUE_TYPE_REGISTRY, AscensionCraft.MOD_ID);
    public static final DeferredHolder<TechniqueType,TechniqueType> SIMPLE_TECHNIQUE_TYPE = TECHNIQUE_TYPES.register(
            "simple_technique",
            SimpleTechniqueType::new
    );
    public static final DeferredHolder<TechniqueType,TechniqueType> KILL_PROGRESSION_TECHNIQUE_TYPE = TECHNIQUE_TYPES.register(
            "kill_progression_technique",
            KillProgressionTechniqueType::new
    );

    public static void register(IEventBus eventBus){

        TECHNIQUE_TYPES.register(eventBus);
    }
}
